//
//  StreamChat.h
//  StreamChat_v3
//
//  Created by Vojta on 26/05/2020.
//  Copyright © 2020 Stream.io Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for StreamChat
FOUNDATION_EXPORT double StreamChat_v3VersionNumber;

//! Project version string for StreamChat
FOUNDATION_EXPORT const unsigned char StreamChat_v3VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StreamChat_v3/PublicHeader.h>


